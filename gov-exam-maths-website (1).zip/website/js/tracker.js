/* tracker.js — mastery tracker + 30-day calendar (localStorage). */
const PRIORITY = [
  { label: "Number System", topics: ["Number System"], tier: "A" },
  { label: "HCF-LCM", topics: ["HCF-LCM"], tier: "A" },
  { label: "Simplification", topics: ["Simplification"], tier: "A" },
  { label: "Percentage", topics: ["Percentage"], tier: "A" },
  { label: "Ratio-Proportion", topics: ["Ratio-Proportion"], tier: "A" },
  { label: "Algebra", topics: ["Algebra"], tier: "A" },
  { label: "Average", topics: ["Average"], tier: "A" },
  { label: "Profit-Loss", topics: ["Profit-Loss"], tier: "A" },
  { label: "Discount", topics: ["Discount"], tier: "A" },
  { label: "Simple Interest", topics: ["Simple Interest"], tier: "A" },
  { label: "Compound Interest", topics: ["Compound Interest"], tier: "A" },
  { label: "Time-Speed-Distance", topics: ["Time-Speed-Distance"], tier: "A" },
  { label: "Trains + Boats-Streams", topics: ["Trains", "Boats-Streams"], tier: "B / C" },
  { label: "Time-Work", topics: ["Time-Work"], tier: "A" },
  { label: "Pipes-Cisterns", topics: ["Pipes-Cisterns"], tier: "B" },
  { label: "Ages", topics: ["Ages"], tier: "B" },
  { label: "Mixture-Alligation", topics: ["Mixture-Alligation"], tier: "C" },
  { label: "Geometry", topics: ["Geometry"], tier: "A" },
  { label: "Circles-Polygons", topics: ["Circles-Polygons"], tier: "A" },
  { label: "Mensuration 2D", topics: ["Mensuration 2D"], tier: "A" },
  { label: "Mensuration 3D", topics: ["Mensuration 3D"], tier: "A" },
  { label: "Trigonometry", topics: ["Trigonometry"], tier: "A (SSC) / B (Railway)" },
  { label: "Coordinate Geometry", topics: ["Coordinate Geometry"], tier: "C" },
  { label: "Data Interpretation", topics: ["Data Interpretation"], tier: "A (SSC)" },
  { label: "Elementary Statistics", topics: ["Elementary Statistics"], tier: "B" },
  { label: "Sequences and Series", topics: ["Sequences and Series"], tier: "C" },
  { label: "Set Theory / Probability / P&C", topics: ["Set Theory", "Probability", "Permutation and Combination"], tier: "D" },
];
const LEVELS = ["Not started", "L1 Recall", "L2 Single-step", "L3 Multi-step", "L4 Mixed/timed", "L5 Error-proof"];
async function initTracker() {
  const wrap = document.getElementById("trackerTable");
  if (!wrap) return;
  const cis = await loadJSON("data/cis.json");
  const ranks = Object.keys(cis.scores);
  const mastery = getMastery();
  const rows = PRIORITY.map((row, i) => {
    const primary = row.topics[0];
    const rank = ranks.indexOf(primary) + 1;
    const cur = mastery[row.label] == null ? 0 : mastery[row.label];
    return '<tr><td class="n">' + (i + 1) + '</td><td><strong>' + esc(row.label) + '</strong></td>' +
      '<td><span class="badge badge-tier">Tier ' + esc(row.tier) + '</span></td>' +
      '<td class="n">' + (rank ? "#" + rank + ' · ' + cis.scores[primary].toFixed(3) : "—") + '</td>' +
      '<td><select data-topic="' + esc(row.label) + '">' +
      LEVELS.map((l, v) => '<option value="' + v + '"' + (cur === v ? ' selected' : '') + '>' + l + '</option>').join("") +
      '</select></td></tr>';
  }).join("");
  wrap.innerHTML = '<table><thead><tr><th class="n">#</th><th>Priority topic</th><th>Tier</th><th class="n">CIS</th><th>Your level</th></tr></thead><tbody>' + rows + '</tbody></table>';
  wrap.querySelectorAll("select").forEach(sel => sel.addEventListener("change", () => {
    const m = getMastery();
    m[sel.dataset.topic] = Number(sel.value);
    storeSet("gems-mastery-v1", m);
    renderTrackerSummary();
  }));
  renderTrackerSummary();
}
function renderTrackerSummary() {
  const el = document.getElementById("trackerSummary");
  if (!el) return;
  const m = getMastery();
  const vals = PRIORITY.map(r => m[r.label] || 0);
  const l3 = vals.filter(v => v >= 3).length;
  const avg = vals.length ? (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1) : "0.0";
  const days = Object.values(getDays()).filter(Boolean).length;
  el.innerHTML = '<div class="grid grid-4">' +
    '<div class="card"><div class="stat-num">' + l3 + ' / ' + PRIORITY.length + '</div><div class="stat-label">Topics at L3 or above</div></div>' +
    '<div class="card"><div class="stat-num">' + avg + '</div><div class="stat-label">Average mastery level</div></div>' +
    '<div class="card"><div class="stat-num">' + days + ' / 30</div><div class="stat-label">Calendar days done</div></div>' +
    '<div class="card"><div class="stat-num">' + countMarks() + '</div><div class="stat-label">Library marks saved</div></div></div>';
}
async function initCalendar() {
  const wrap = document.getElementById("calendarWrap");
  if (!wrap) return;
  const cal = await loadJSON("data/calendar.json");
  const days = getDays();
  const blocks = {};
  cal.days.forEach(d => { (blocks[d.block] = blocks[d.block] || []).push(d); });
  wrap.innerHTML = Object.entries(blocks).map(([b, ds]) =>
    '<h2 style="margin-top:28px">Block ' + b + ' — ' + esc(cal.blocks[b]) + '</h2>' +
    '<div class="cal-grid">' + ds.map(d =>
      '<div class="cal-day' + (days[d.day] ? ' done' : '') + '">' +
      '<label><input type="checkbox" data-day="' + d.day + '"' + (days[d.day] ? ' checked' : '') + '> ' +
      '<strong>Day ' + d.day + '</strong></label>' +
      '<div style="font-size:14px;margin-top:6px">' + esc(d.topic) + '</div>' +
      '<div class="small muted">' + (d.records != null ? fmt(d.records) + ' records · ' : '') +
      d.target + ' · ' + esc(d.drill) + '</div>' +
      '<div class="small muted">Traps: ' + esc(d.traps) + '</div></div>').join("") + '</div>'
  ).join("");
  wrap.querySelectorAll("input[type=checkbox]").forEach(box => box.addEventListener("change", () => {
    const d = getDays();
    d[box.dataset.day] = box.checked;
    storeSet("gems-days-v1", d);
    box.closest(".cal-day").classList.toggle("done", box.checked);
    renderTrackerSummary();
    const prog = document.getElementById("calProgress");
    if (prog) {
      const done = Object.values(getDays()).filter(Boolean).length;
      prog.innerHTML = '<div class="bar-track"><div class="bar-fill t2" style="width:' + (100 * done / 30) + '%"></div></div><p class="small">' + done + ' / 30 days done</p>';
    }
  }));
  const prog = document.getElementById("calProgress");
  if (prog) {
    const done = Object.values(getDays()).filter(Boolean).length;
    prog.innerHTML = '<div class="bar-track"><div class="bar-fill t2" style="width:' + (100 * done / 30) + '%"></div></div><p class="small">' + done + ' / 30 days done</p>';
  }
  const note = document.getElementById("calNotes");
  if (note) note.innerHTML = '<div class="callout">' + esc(cal.order_note) + '</div>' +
    '<p class="small muted">' + esc(cal.count_note) + '</p>' +
    '<h3>Exam-family variants (swap rules, not a second calendar)</h3>' +
    '<ul><li><strong>SSC (CGL/CHSL/CPO):</strong> move Trigonometry (Day 24) to right after Day 8 (Algebra), and Data Interpretation (Day 26) to right after Day 9 (Average); move Trains/Boats and Pipes to the Day 27–28 tail.</li>' +
    '<li><strong>Railway (NTPC/Group D/ALP/Technician):</strong> keep base order; for NTPC, move P&amp;C before Sequences; de-prioritise Trigonometry and Coordinate Geometry to the tail.</li>' +
    '<li><strong>GD/MTS/RPF:</strong> move Profit-Loss and Average to the top of the commercial block; move Trigonometry, DI and Coordinate Geometry to the tail.</li></ul>';
}
function initProgressButtons() {
  document.querySelectorAll("[data-export-progress]").forEach(b => b.addEventListener("click", exportProgress));
  document.querySelectorAll("[data-import-progress]").forEach(inp => inp.addEventListener("change", () => {
    if (inp.files[0]) importProgressFile(inp.files[0], ok => {
      alert(ok ? "Progress imported. Reloading." : "Could not read that file.");
      if (ok) location.reload();
    });
  }));
}
document.addEventListener("DOMContentLoaded", () => { initTracker(); initCalendar(); initProgressButtons(); });
