/* library.js — paper library search/filters/pagination + paper detail + marks. */
function setParams(p) {
  history.replaceState(null, "", location.pathname + (p.toString() ? "?" + p.toString() : ""));
}
let LIB_ROWS = [];
async function initLibrary() {
  const listEl = document.getElementById("libResults");
  if (!listEl) return;
  await siteIndex();
  const [index, exams] = await Promise.all([loadJSON("data/papers_index.json"), loadJSON("data/exams.json")]);
  LIB_ROWS = index.map(decodePaper);
  const params = getParams();
  const state = {
    q: params.get("q") || "", exams: (params.get("exam") || "").split(",").filter(Boolean),
    year: params.get("year") || "", shift: params.get("shift") || "",
    topic: params.get("topic") || "", diff: params.get("diff") || "",
    type: params.get("type") || "", key: params.get("key") || "",
    sort: params.get("sort") || "date-desc", page: Math.max(1, Number(params.get("page") || 1)),
  };
  const years = [...new Set(LIB_ROWS.map(r => r.year))].sort().reverse();
  const filtersEl = document.getElementById("libFilters");
  filtersEl.innerHTML =
    '<div class="filter-group"><label>Search (paper id, exam, topic)</label>' +
    '<input type="search" id="fQ" placeholder="e.g. 2026-Tier1, CGL, Trigonometry" value="' + esc(state.q) + '"></div>' +
    '<div class="filter-group"><label>Exam</label><div class="chip-row" id="fExams">' +
    exams.map(e => '<button class="chip' + (state.exams.includes(e.code) ? ' on' : '') +
      '" data-exam="' + esc(e.code) + '">' + esc(e.display) + '</button>').join("") + '</div></div>' +
    '<div class="filter-group"><label>Year</label><select id="fYear"><option value="">All years</option>' +
    years.map(y => '<option value="' + y + '"' + (state.year === y ? ' selected' : '') + '>' + y + '</option>').join("") + '</select></div>' +
    '<div class="filter-group"><label>Shift</label><div class="chip-row" id="fShift">' +
    ["S1", "S2", "S3", "S4", "not recorded"].map(s => '<button class="chip' + (state.shift === s ? ' on' : '') +
      '" data-shift="' + s + '">' + s + '</button>').join("") + '</div></div>' +
    '<div class="filter-group"><label>Topic in paper</label><select id="fTopic"><option value="">Any topic</option>' +
    TOPIC_NAMES.map(t => '<option value="' + esc(t) + '"' + (state.topic === t ? ' selected' : '') + '>' + esc(t) + '</option>').join("") + '</select></div>' +
    '<div class="filter-group"><label>Difficulty present</label><div class="chip-row" id="fDiff">' +
    ["easy", "medium", "hard"].map(d => '<button class="chip' + (state.diff === d ? ' on' : '') +
      '" data-diff="' + d + '">' + d + '</button>').join("") + '</div></div>' +
    '<div class="filter-group"><label>Paper type</label><div class="chip-row" id="fType">' +
    ["official", "bilingual-official", "similar", "memory-based"].map(t => '<button class="chip' + (state.type === t ? ' on' : '') +
      '" data-type="' + t + '">' + t + '</button>').join("") + '</div></div>' +
    '<div class="filter-group"><label>Answer key</label><div class="chip-row" id="fKey">' +
    '<button class="chip' + (state.key === "present" ? ' on' : '') + '" data-key="present">Key present</button>' +
    '<button class="chip' + (state.key === "absent" ? ' on' : '') + '" data-key="absent">Key not present</button></div></div>' +
    '<div class="filter-group"><label>Sort</label><select id="fSort">' +
    [["date-desc", "Date (newest first)"], ["date-asc", "Date (oldest first)"],
     ["total-desc", "Most questions"], ["exam", "Exam A–Z"]].map(([v, l]) =>
      '<option value="' + v + '"' + (state.sort === v ? ' selected' : '') + '>' + l + '</option>').join("") + '</select></div>' +
    '<button class="chip" id="fClear" style="width:100%;padding:9px">Clear all filters</button>';
  let debounce;
  document.getElementById("fQ").setAttribute("data-global-search", "");
  const rerender = (resetPage) => {
    if (resetPage) state.page = 1;
    renderLibList(state);
    const p = new URLSearchParams();
    if (state.q) p.set("q", state.q);
    if (state.exams.length) p.set("exam", state.exams.join(","));
    ["year", "shift", "topic", "diff", "type", "key", "sort"].forEach(k => { if (state[k]) p.set(k, state[k]); });
    if (state.page > 1) p.set("page", state.page);
    setParams(p);
  };
  document.getElementById("fQ").addEventListener("input", e => {
    state.q = e.target.value.trim();
    clearTimeout(debounce);
    debounce = setTimeout(() => rerender(true), 150);
  });
  filtersEl.querySelectorAll("#fExams .chip").forEach(b => b.addEventListener("click", () => {
    const code = b.dataset.exam;
    state.exams = state.exams.includes(code) ? state.exams.filter(x => x !== code) : [...state.exams, code];
    b.classList.toggle("on");
    rerender(true);
  }));
  const chipGroup = (id, key) => filtersEl.querySelectorAll("#" + id + " .chip").forEach(b =>
    b.addEventListener("click", () => {
      state[key] = (state[key] === b.dataset[key]) ? "" : b.dataset[key];
      filtersEl.querySelectorAll("#" + id + " .chip").forEach(x => x.classList.toggle("on", state[key] === x.dataset[key]));
      rerender(true);
    }));
  chipGroup("fShift", "shift"); chipGroup("fDiff", "diff"); chipGroup("fType", "type"); chipGroup("fKey", "key");
  ["fYear", "fTopic", "fSort"].forEach(id => document.getElementById(id).addEventListener("change", e => {
    state[id === "fYear" ? "year" : id === "fTopic" ? "topic" : "sort"] = e.target.value;
    rerender(true);
  }));
  document.getElementById("fClear").addEventListener("click", () => {
    location.href = "library.html";
  });
  window.__libRerender = rerender;
  rerender(false);
}
function applyLibFilters(state) {
  let rows = LIB_ROWS.filter(r => {
    if (state.q) {
      const q = state.q.toLowerCase();
      const hay = (r.id + " " + r.examDisplay + " " + r.topics.map(t => t.name).join(" ")).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    if (state.exams.length && !state.exams.includes(r.exam)) return false;
    if (state.year && r.year !== state.year) return false;
    if (state.shift && r.shift !== state.shift) return false;
    if (state.topic && !r.topics.some(t => t.name === state.topic)) return false;
    if (state.diff && r[state.diff] <= 0) return false;
    if (state.type && r.type !== state.type) return false;
    if (state.key === "present" && r.keyPresent <= 0) return false;
    if (state.key === "absent" && r.keyPresent > 0) return false;
    return true;
  });
  if (state.sort === "date-desc") rows.sort((a, b) => (b.date === "unknown" ? "" : b.date).localeCompare(a.date === "unknown" ? "" : a.date));
  if (state.sort === "date-asc") rows.sort((a, b) => (a.date === "unknown" ? "9999" : a.date).localeCompare(b.date === "unknown" ? "9999" : b.date));
  if (state.sort === "total-desc") rows.sort((a, b) => b.total - a.total);
  if (state.sort === "exam") rows.sort((a, b) => a.examDisplay.localeCompare(b.examDisplay));
  return rows;
}
function renderLibList(state) {
  const rows = applyLibFilters(state);
  const per = 20, pages = Math.max(1, Math.ceil(rows.length / per));
  if (state.page > pages) state.page = pages;
  const slice = rows.slice((state.page - 1) * per, state.page * per);
  const certainSum = rows.reduce((s, r) => s + r.certain, 0);
  document.getElementById("libCount").innerHTML =
    "<strong>" + fmt(rows.length) + " papers</strong> · " + fmt(certainSum) +
    " certain records in this view · page " + state.page + " of " + pages;
  document.getElementById("libResults").innerHTML = slice.length ? slice.map(r =>
    '<div class="paper-row"><a href="paper.html?id=' + encodeURIComponent(r.id) + '"><strong>' + esc(r.id) + '</strong></a>' +
    ' <span class="badge ' + (r.family === "SSC" ? "badge-ssc" : "badge-rail") + '">' + esc(r.examDisplay) + '</span>' +
    ' <span class="badge">' + esc(r.type) + '</span>' +
    '<div class="muted small">' + esc(r.date) + ' · Shift ' + esc(r.shift) + ' · ' + esc(r.stage || "—") +
    ' · ' + r.total + ' questions · ' + r.certain + ' certain · key present on ' + r.keyPresent +
    ' · difficulty E' + r.easy + '/M' + r.medium + '/H' + r.hard + '</div>' +
    '<div class="small">Top topics: ' + r.topics.map(t => esc(t.name) + " (" + t.count + ")").join(" · ") + '</div></div>'
  ).join("") : '<div class="empty"><strong>No papers match.</strong><p>Loosen a filter, or clear all filters above.</p></div>';
  document.getElementById("libPager").innerHTML =
    '<button ' + (state.page <= 1 ? "disabled" : "") + ' data-pg="-1">← Previous</button>' +
    '<span class="small">Page ' + state.page + ' of ' + pages + '</span>' +
    '<button ' + (state.page >= pages ? "disabled" : "") + ' data-pg="1">Next →</button>';
  document.querySelectorAll("#libPager button[data-pg]").forEach(b => b.addEventListener("click", () => {
    state.page += Number(b.dataset.pg);
    window.__libRerender(false);
    document.getElementById("libResults").scrollIntoView({ behavior: "smooth" });
  }));
}
async function initPaper() {
  const wrap = document.getElementById("paperDetail");
  if (!wrap) return;
  const id = getParams().get("id") || "";
  if (!id) { wrap.innerHTML = '<div class="empty">No paper selected. Go to the <a href="library.html">library</a>.</div>'; return; }
  try {
    const [paper, idx] = await Promise.all([
      loadJSON("data/papers/" + encodeURIComponent(id) + ".json"), siteIndex()]);
    const marks = getMarks();
    const myMarks = marks[id] || {};
    const keyPresent = paper.questions.filter(q => q.key === "present").length;
    wrap.innerHTML =
      '<div class="page-hero"><p class="eyebrow">' + esc(paper.exam_display) + ' · ' + esc(paper.stage || "—") + '</p>' +
      '<h1 style="font-size:28px">' + esc(paper.id) + '</h1>' +
      '<p class="muted">' + esc(paper.date) + ' · Shift ' + esc(paper.shift) + ' · ' + esc(paper.type) +
      (paper.maths_section ? ' · Section: ' + esc(paper.maths_section) : '') +
      (paper.cycle_note ? ' · ' + esc(paper.cycle_note) : '') + '</p></div>' +
      '<div class="grid grid-4">' +
      '<div class="card"><div class="stat-num">' + paper.total + '</div><div class="stat-label">Maths questions tagged</div></div>' +
      '<div class="card"><div class="stat-num">' + paper.questions.filter(q => q.key === "present").length + '</div><div class="stat-label">With key present</div></div>' +
      '<div class="card"><div class="stat-num">' + Object.keys(myMarks).length + '</div><div class="stat-label">Your marked questions</div></div>' +
      '<div class="card"><div class="stat-num">' + esc(paper.type) + '</div><div class="stat-label">Paper type</div></div></div>' +
      '<div class="callout">Question text and options are <strong>not reproduced</strong> here (project copyright ' +
      'rule — the tagging records contain tags only). Use the source PDF for the original wording. ' +
      'Answers below are bare values from the paper\u2019s own key, shown behind a toggle.</div>' +
      '<div class="table-wrap"><table><thead><tr><th class="n">Q</th><th>Topic</th><th>Sub-topic</th>' +
      '<th>Concept tags</th><th>Type / Model</th><th>Difficulty</th><th>Key</th><th>Answer</th><th>Your marks</th></tr></thead><tbody>' +
      paper.questions.map(q => {
        const m = myMarks[q.n] || [];
        const btn = mark => '<button class="mark-btn' + (m.includes(mark) ? ' on' : '') +
          '" data-q="' + q.n + '" data-mark="' + mark + '">' + mark + '</button>';
        return '<tr><td class="n">' + q.n + '</td><td>' + esc(q.topic) + '</td><td>' + esc(q.sub) + '</td>' +
          '<td class="small">' + (q.tags || []).map(t => esc(t)).join(" · ") + '</td>' +
          '<td class="small">' + esc(q.type || "—") + (q.model ? '<br><span class="muted">' + esc(q.model) + '</span>' : '') + '</td>' +
          '<td><span class="badge">' + esc(q.diff) + '</span>' + (q.trick ? '<br><span class="small muted">' + esc(q.trick) + '</span>' : '') + '</td>' +
          '<td>' + esc(q.key) + '</td>' +
          '<td>' + (q.key === "present"
            ? '<button class="mark-btn" data-ans="' + esc(q.ans) + '" onclick="this.textContent=this.dataset.ans;this.disabled=true">Show</button>'
            : '<span class="muted">—</span>') + '</td>' +
          '<td>' + btn("bookmark") + btn("solved") + btn("incorrect") + btn("revision") + '</td></tr>';
      }).join("") + '</tbody></table></div>' +
      '<div id="paperRelated" style="margin-top:24px"></div>';
    wrap.querySelectorAll("[data-mark]").forEach(b => b.addEventListener("click", () => {
      toggleMark(id, Number(b.dataset.q), b.dataset.mark);
      initPaper();
    }));
    const index = await loadJSON("data/papers_index.json");
    const mineRow = index.find(r => r.i === id);
    const mine = mineRow ? decodePaper(mineRow) : { topics: [] };
    const rel = index.map(decodePaper).filter(r => r.id !== id && r.exam === paper.exam)
      .map(r => ({ r, shared: r.topics.filter(t => (mine.topics || []).some(mt => mt.name === t.name)).length }))
      .filter(x => x.shared > 0).sort((a, b) => b.shared - a.shared).slice(0, 5);
    document.getElementById("paperRelated").innerHTML = rel.length ?
      '<h3>Related papers (same exam, shared top topics)</h3>' +
      rel.map(x => '<p><a href="paper.html?id=' + encodeURIComponent(x.r.id) + '">' + esc(x.r.id) + '</a>' +
        ' — ' + x.shared + ' shared top topics · ' + x.r.total + ' questions</p>').join("") : "";
  } catch (e) {
    wrap.innerHTML = '<div class="empty"><strong>Paper not found.</strong><p>' + esc(e.message) +
      '</p><p>Return to the <a href="library.html">library</a>.</p></div>';
  }
}
document.addEventListener("DOMContentLoaded", () => { initLibrary(); initPaper(); });
