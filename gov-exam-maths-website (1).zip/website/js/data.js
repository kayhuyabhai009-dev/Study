/* data.js — loading, decoding, formatting, localStorage stores. */
const cache = {};
async function loadJSON(path) {
  if (cache[path]) return cache[path];
  let r;
  try {
    r = await fetch(path);
  } catch (e) {
    showLoadError();
    throw new Error("Could not load " + path + " (network blocked)");
  }
  if (!r.ok) {
    showLoadError();
    throw new Error("Could not load " + path + " (" + r.status + ")");
  }
  const j = await r.json();
  cache[path] = j;
  return j;
}
/* If data cannot load (most often: the site was opened via file://, where browsers
   block JSON fetch), say so plainly instead of leaving skeleton rows forever. */
function showLoadError() {
  if (document.getElementById("loadErrorBanner")) return;
  const div = document.createElement("div");
  div.id = "loadErrorBanner";
  div.style.cssText = "background:#F6E2DC;border-bottom:2px solid #B3402A;padding:12px 16px;font-size:14px;position:sticky;top:0;z-index:200";
  if (location.protocol === "file:") {
    div.innerHTML = "<strong>Data load nahi hua — file ko double-click se khola gaya hai.</strong> " +
      "Is site ka data JSON files se load hota hai, jo file:// par browsers block kar dete hain. " +
      "Server se chalao: <span class=\"mono\">cd website && python3 -m http.server 8000</span>, phir " +
      "<span class=\"mono\">http://localhost:8000</span> kholo. Wahan sab kuch chalega.";
  } else {
    div.innerHTML = "<strong>Data load nahi hua.</strong> Page reload karo; agar baar-baar fail ho to server check karo.";
  }
  document.body.prepend(div);
}
const fmt = n => (n == null ? "—" : Number(n).toLocaleString("en-IN"));
function getParams() { return new URLSearchParams(location.search); }
const pct = (a, b) => (b ? (100 * a / b).toFixed(1) + "%" : "—");
const EXAM_DISPLAY = { CGL: "CGL", CHSL: "CHSL", CPO: "CPO", MTS: "MTS", GD: "GD Constable",
  SP: "Selection Post", HC: "Delhi Police HC", DPC: "Delhi Police Constable", NTPC: "NTPC",
  GroupD: "Group D", ALP: "ALP", Technician: "Technician", "RPF-Constable": "RPF Constable",
  "RPF-SI": "RPF SI", JE: "JE", "MI-NonTranslator": "MI Non-Translator",
  "MI-Translator": "MI Translator", Paramedical: "Paramedical" };
const FAMILY = { CGL: "SSC", CHSL: "SSC", CPO: "SSC", MTS: "SSC", GD: "SSC", SP: "SSC",
  HC: "SSC", DPC: "SSC", NTPC: "Railway", GroupD: "Railway", ALP: "Railway",
  Technician: "Railway", "RPF-Constable": "Railway", "RPF-SI": "Railway", JE: "Railway",
  "MI-NonTranslator": "Railway", "MI-Translator": "Railway", Paramedical: "Railway" };
let TOPIC_NAMES = [];
async function siteIndex() {
  const idx = await loadJSON("data/index.json");
  TOPIC_NAMES = idx.topic_ids;
  return idx;
}
function decodePaper(row) {
  return { id: row.i, exam: row.e, examDisplay: EXAM_DISPLAY[row.e] || row.e,
    family: FAMILY[row.e] || "", date: row.d,
    year: row.d === "unknown" ? "unknown" : row.d.slice(0, 4),
    shift: row.s, stage: row.t, type: row.y, total: row.n, certain: row.c,
    easy: row.df[0], medium: row.df[1], hard: row.df[2], keyPresent: row.k,
    topics: (row.tp || []).map(([tid, c]) => ({ name: TOPIC_NAMES[tid] || ("Topic " + tid), count: c })) };
}
function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, c =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
/* ---- localStorage stores (progress lives in the browser only) ---- */
function storeGet(key, fallback) {
  try { const v = JSON.parse(localStorage.getItem(key)); return v == null ? fallback : v; }
  catch (e) { return fallback; }
}
function storeSet(key, val) { localStorage.setItem(key, JSON.stringify(val)); }
function getMarks() { return storeGet("gems-marks-v1", {}); }
function toggleMark(paperId, qn, mark) {
  const m = getMarks();
  m[paperId] = m[paperId] || {};
  m[paperId][qn] = m[paperId][qn] || [];
  const arr = m[paperId][qn];
  const i = arr.indexOf(mark);
  if (i >= 0) arr.splice(i, 1); else arr.push(mark);
  if (!arr.length) delete m[paperId][qn];
  storeSet("gems-marks-v1", m);
  return m;
}
function countMarks() {
  const m = getMarks();
  let n = 0;
  Object.values(m).forEach(qs => Object.values(qs).forEach(a => n += a.length));
  return n;
}
function getMastery() { return storeGet("gems-mastery-v1", {}); }
function getDays() { return storeGet("gems-days-v1", {}); }
function exportProgress() {
  const blob = new Blob([JSON.stringify({ marks: getMarks(), mastery: getMastery(), days: getDays() }, null, 1)],
    { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "gov-exam-maths-progress.json";
  a.click();
  URL.revokeObjectURL(a.href);
}
function importProgressFile(file, done) {
  const rd = new FileReader();
  rd.onload = () => {
    try {
      const j = JSON.parse(rd.result);
      if (j.marks) storeSet("gems-marks-v1", j.marks);
      if (j.mastery) storeSet("gems-mastery-v1", j.mastery);
      if (j.days) storeSet("gems-days-v1", j.days);
      done(true);
    } catch (e) { done(false); }
  };
  rd.readAsText(file);
}
